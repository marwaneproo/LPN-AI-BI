CREATE TABLE business.c_order (
    c_order_id integer PRIMARY KEY,
    documentno text NOT NULL,
    dateordered timestamp NOT NULL,
    grandtotal numeric(18, 2) NOT NULL
);

CREATE TABLE business.c_bpartner (
    c_bpartner_id integer PRIMARY KEY,
    value text NOT NULL,
    name text NOT NULL
);
